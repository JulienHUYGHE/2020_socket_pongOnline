#include <clienttcp.h>
#include <QCoreApplication>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    ClientTcp Client;
    Client.TaperMessage();

    return a.exec();
}
