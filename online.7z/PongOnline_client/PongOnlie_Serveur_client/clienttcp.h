#define CLIENTTCP_H
#define CLIENTTCP_H
#include <QtNetwork>
#include <QObject>


class ClientTcp : public QObject
{

Q_OBJECT

private slots:

    void lireTexte();
    void afficherErreur( QAbstractSocket::SocketError socketError);

private :
    QTcpSocket *m_tcpSocket;
    quint16 m_blockSize;
    QNetworkSession *m_networkSession;

public:
    ClientTcp();
    void TaperMessage();
    bool test(int a);

};
