#ifndef SERVEUR_H
#define SERVEUR_H
#include <QtNetwork>
#include <QObject>

class Serveur : public QObject
{

Q_OBJECT

private slots:
    void sessionOuverte();
    void connexionClient();
    void lireTexte();

private:

    QTcpServer *m_tcp_server;
    QTcpSocket *m_socket_client;
    QNetworkSession *m_network_session;
    quint16 m_blockSize;

public:
    Serveur();
    void TaperMessage();

};

#endif // SERVEUR_H
